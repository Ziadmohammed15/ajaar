import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../services/supabaseClient';
import { useAuth } from '../context/AuthContext';
import { motion } from 'framer-motion';
import {
  Users, ShoppingBag, Calendar, Star, 
  UserPlus, Trash2, Edit, Search, Shield
} from 'lucide-react';

interface User {
  id: string;
  name: string;
  phone: string;
  role: 'admin' | 'provider' | 'customer';
  created_at: string;
}

interface Service {
  id: string;
  title: string;
  provider: { name: string };
  price: number;
  status: 'active' | 'inactive';
  image_url?: string;
}

interface Booking {
  id: string;
  service: { title: string };
  client: { name: string };
  date: string;
  status: 'confirmed' | 'pending' | 'cancelled';
}

const AdminDashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [users, setUsers] = useState<User[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [selectedTab, setSelectedTab] = useState<'users' | 'services' | 'bookings'>('users');
  const [adminStats, setAdminStats] = useState({
    avgRating: 0,
    activeServices: 0,
    confirmedBookings: 0
  });

  useEffect(() => {
    checkAdminAccess();
    loadDashboardData();
  }, []);

  const checkAdminAccess = async () => {
    if (!user) {
      navigate('/login');
      return;
    }

    const { data: roleData } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id)
      .single();

    if (roleData?.role !== 'admin') {
      navigate('/');
    }
  };

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      
      // Load users with their roles
      const { data: usersData } = await supabase
        .from('profiles')
        .select(`
          id, name, phone, created_at,
          role:user_roles(role)
        `)
        .order('created_at', { ascending: false });
      
      if (usersData) {
        setUsers(usersData.map(u => ({
          ...u,
          role: u.role?.role || 'customer'
        })));
      }

      // Load services with provider info
      const { data: servicesData } = await supabase
        .from('services')
        .select(`
          id, title, price, status, image_url,
          provider:profiles(name)
        `)
        .order('created_at', { ascending: false });
      
      if (servicesData) setServices(servicesData);

      // Load bookings with related data
      const { data: bookingsData } = await supabase
        .from('bookings')
        .select(`
          id, date, status,
          service:services(title),
          client:profiles!bookings_client_id_fkey(name)
        `)
        .order('created_at', { ascending: false });
      
      if (bookingsData) setBookings(bookingsData);

      // Load statistics
      const { data: statsData } = await supabase.rpc('get_admin_stats');
      if (statsData) {
        setAdminStats({
          avgRating: statsData.avg_rating || 0,
          activeServices: statsData.active_services || 0,
          confirmedBookings: statsData.confirmed_bookings || 0
        });
      }
    } catch (error) {
      console.error('Error loading dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteUser = async (userId: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا المستخدم؟')) return;
    
    try {
      // First delete from auth if it's the same user
      if (user?.id === userId) {
        await supabase.auth.admin.deleteUser(userId);
      }
      
      const { error } = await supabase
        .from('profiles')
        .delete()
        .eq('id', userId);

      if (error) throw error;
      
      setUsers(users.filter(u => u.id !== userId));
    } catch (error) {
      console.error('Error deleting user:', error);
      alert('حدث خطأ أثناء حذف المستخدم');
    }
  };

  const handleUpdateUserRole = async (userId: string, newRole: string) => {
    try {
      const { error } = await supabase
        .from('user_roles')
        .upsert({ 
          user_id: userId, 
          role: newRole 
        }, {
          onConflict: 'user_id'
        });

      if (error) throw error;
      
      setUsers(users.map(u => 
        u.id === userId ? { ...u, role: newRole } : u
      ));
    } catch (error) {
      console.error('Error updating user role:', error);
    }
  };

  // ... باقي الدوال بنفس النمط مع تحسينات الأمان ...

  return (
    <div className="min-h-screen bg-secondary-50 dark:bg-secondary-900">
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="mb-8 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold dark:text-white">لوحة التحكم الإدارية</h1>
            <p className="text-secondary-600 dark:text-secondary-400">
              {user?.user_metadata?.name || 'مسؤول النظام'}
            </p>
          </div>
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <Shield className="text-primary-500" />
            <span className="bg-primary-100 dark:bg-primary-900/30 px-3 py-1 rounded-full text-sm">
              مشرف
            </span>
          </div>
        </div>

        {/* الإحصائيات */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {/* ... إحصائيات محسنة مع بيانات حقيقية ... */}
        </div>

        {/* محتوى لوحة التحكم */}
        {loading ? (
          <div className="text-center py-12">
            <div className="w-16 h-16 border-4 border-primary-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
            <p className="mt-4 text-secondary-600 dark:text-secondary-400">جاري تحميل البيانات...</p>
          </div>
        ) : (
          <div className="bg-white dark:bg-secondary-800 rounded-xl shadow-sm overflow-hidden">
            {/* ... محتوى الجداول مع تحسينات ... */}
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;