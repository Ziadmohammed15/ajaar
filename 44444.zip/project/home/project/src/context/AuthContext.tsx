import React, { createContext, useState, useEffect, useContext } from 'react';
import { supabase } from '../services/supabaseClient';
import { Session, User } from '@supabase/supabase-js';
import { useNavigate } from 'react-router-dom';

interface AuthContextType {
  session: Session | null;
  user: User | null;
  userRole: string | null;
  loading: boolean;
  phoneVerified: boolean;
  signInWithPhone: (phone: string, password: string) => Promise<{ error: any }>;
  signUp: (phone: string, userData: any) => Promise<{ error: any, user: any }>;
  signOut: () => Promise<void>;
  updateProfile: (data: any) => Promise<{ error: any }>;
  setPhoneVerified: (verified: boolean) => void;
  checkUserRole: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [userRole, setUserRole] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [phoneVerified, setPhoneVerified] = useState(false);
  const navigate = useNavigate();

  const checkUserRole = async (userId: string) => {
    const { data, error } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', userId)
      .single();
    
    if (!error && data) {
      setUserRole(data.role);
    } else {
      setUserRole('customer');
    }
  };

  useEffect(() => {
    const getSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setSession(session);
      setUser(session?.user ?? null);
      
      if (session?.user) {
        await checkUserRole(session.user.id);
      }
      
      setLoading(false);
    };

    getSession();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      setSession(session);
      setUser(session?.user ?? null);
      
      if (session?.user) {
        await checkUserRole(session.user.id);
        
        // Redirect to phone verification if needed
        if (event === 'SIGNED_IN' && !phoneVerified) {
          navigate('/verify-phone');
        }
      }
      
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  const signInWithPhone = async (phone: string, password: string) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        phone,
        password
      });

      if (error) throw error;
      
      if (data.session) {
        setSession(data.session);
        setUser(data.session.user);
        await checkUserRole(data.session.user.id);
      }
      
      return { error: null };
    } catch (error) {
      console.error('Sign in error:', error);
      return { error };
    }
  };

  const signUp = async (phone: string, userData: any) => {
    try {
      // First sign up the user
      const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
        phone,
        password: userData.password,
        options: {
          data: {
            name: userData.name,
            phone_verified: false
          }
        }
      });

      if (signUpError) throw signUpError;
      
      if (signUpData.user) {
        // Create user role (default to customer)
        await supabase
          .from('user_roles')
          .insert({
            user_id: signUpData.user.id,
            role: 'customer'
          });

        // Create profile
        const { error: profileError } = await supabase
          .from('profiles')
          .insert({
            id: signUpData.user.id,
            name: userData.name,
            phone,
            email: userData.email,
            role: 'customer'
          });

        if (profileError) throw profileError;
        
        setUser(signUpData.user);
        setUserRole('customer');
        return { error: null, user: signUpData.user };
      }
      
      return { error: new Error('User not created'), user: null };
    } catch (error) {
      console.error('Sign up error:', error);
      return { error, user: null };
    }
  };

  // ... باقي الدوال بنفس النمط مع تحسينات الأمان ...

  return (
    <AuthContext.Provider value={{ 
      session, 
      user, 
      userRole,
      loading,
      phoneVerified,
      signInWithPhone,
      signUp, 
      signOut, 
      updateProfile,
      setPhoneVerified,
      checkUserRole: () => user ? checkUserRole(user.id) : Promise.resolve()
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};