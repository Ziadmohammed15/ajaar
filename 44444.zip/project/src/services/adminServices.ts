import { createClient } from '@/supabase/client';

export const assignAdminRole = async (userId: string) => {
  const supabase = createClient();
  
  const { data, error } = await supabase
    .from('user_roles')
    .upsert({ 
      user_id: userId, 
      role: 'admin' 
    });

  if (error) throw error;
  return data;
};

export const getAdminUsers = async () => {
  const supabase = createClient();
  
  const { data, error } = await supabase
    .from('admin_users')
    .select('*');

  if (error) throw error;
  return data;
};