import { supabase } from './supabaseClient';

/**
 * خدمة التحقق من رقم الهاتف
 */

// إرسال رمز التحقق
export const sendVerificationCode = async (phoneNumber: string): Promise<{ success: boolean; error?: string }> => {
  try {
    // التحقق من تنسيق رقم الهاتف
    let formattedPhone = phoneNumber;
    if (!formattedPhone.startsWith('+')) {
      formattedPhone = `+${formattedPhone}`;
    }

    // في بيئة التطوير، نستخدم رمز ثابت للتجربة: 123456
    console.log(`رمز التحقق للرقم ${formattedPhone} هو: 123456`);
    
    // محاكاة تأخير الإرسال
    await new Promise(resolve => setTimeout(resolve, 1000));

    return { success: true };
  } catch (error) {
    console.error('خطأ في إرسال رمز التحقق:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'حدث خطأ غير معروف'
    };
  }
};

// التحقق من صحة الرمز
export const verifyCode = async (phoneNumber: string, code: string): Promise<{ success: boolean; error?: string }> => {
  try {
    // في بيئة التطوير، نقبل الرمز 123456 فقط
    const isValid = code === '123456';
    
    if (!isValid) {
      return { 
        success: false, 
        error: 'رمز التحقق غير صحيح. الرمز الصحيح هو 123456'
      };
    }

    // محاكاة تأخير التحقق
    await new Promise(resolve => setTimeout(resolve, 1000));

    return { success: true };
  } catch (error) {
    console.error('خطأ في التحقق من الرمز:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'حدث خطأ غير معروف'
    };
  }
};