import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Header from '../components/Header';
import PhoneVerification from '../components/PhoneVerification';
import { useAuth } from '../context/AuthContext';
import { motion } from 'framer-motion';
import { Check } from 'lucide-react';

const PhoneVerificationPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { setPhoneVerified } = useAuth();
  const [verificationComplete, setVerificationComplete] = useState(false);
  
  // Get phone number from location state
  const phoneNumber = location.state?.phone;
  
  if (!phoneNumber) {
    navigate('/auth');
    return null;
  }

  const handleVerified = () => {
    setPhoneVerified(true);
    setVerificationComplete(true);
    
    // Redirect after a short delay
    setTimeout(() => {
      navigate('/user-type');
    }, 1500);
  };
  
  const handleCancel = () => {
    navigate('/auth');
  };
  
  const handleChangePhone = () => {
    navigate('/auth', { state: { showRegister: true } });
  };

  return (
    <>
      <Header title="التحقق من رقم الهاتف" showBack={true} />
      
      <div className="page-container">
        {verificationComplete ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="glass-morphism p-6 rounded-2xl max-w-md mx-auto text-center"
          >
            <div className="w-16 h-16 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
              <Check className="w-8 h-8 text-green-600 dark:text-green-400" />
            </div>
            <h2 className="text-xl font-bold mb-2 dark:text-white">تم التحقق بنجاح</h2>
            <p className="text-secondary-600 dark:text-secondary-300 mb-6">
              تم التحقق من رقم هاتفك بنجاح. جاري تحويلك...
            </p>
            <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
          </motion.div>
        ) : (
          <PhoneVerification
            phoneNumber={phoneNumber}
            onVerified={handleVerified}
            onCancel={handleCancel}
            onChangePhone={handleChangePhone}
          />
        )}
      </div>
    </>
  );
};

export default PhoneVerificationPage;