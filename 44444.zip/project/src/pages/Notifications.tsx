import React from 'react';
import NotificationsPage from '../components/NotificationsPage';

const Notifications = () => {
  return <NotificationsPage />;
};

export default Notifications;