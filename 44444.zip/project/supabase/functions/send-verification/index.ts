// Follow this setup guide to integrate the Deno language server with your editor:
// https://deno.land/manual/getting_started/setup_your_environment
// This enables autocomplete, go to definition, etc.

import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.7'
import { Twilio } from 'https://esm.sh/twilio@4.23.0'

// Twilio API credentials
const TWILIO_ACCOUNT_SID = Deno.env.get('TWILIO_ACCOUNT_SID') || '';
const TWILIO_AUTH_TOKEN = Deno.env.get('TWILIO_AUTH_TOKEN') || '';
const TWILIO_VERIFY_SERVICE_SID = Deno.env.get('TWILIO_VERIFY_SERVICE_SID') || '';

// Create Twilio client
const twilioClient = new Twilio(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN);

serve(async (req) => {
  try {
    // CORS headers
    const headers = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    };

    // Handle CORS preflight request
    if (req.method === 'OPTIONS') {
      return new Response('ok', { headers });
    }

    // Parse request body
    const { phoneNumber } = await req.json();

    // Validate phone number
    if (!phoneNumber || typeof phoneNumber !== 'string') {
      return new Response(
        JSON.stringify({ error: 'رقم الهاتف مطلوب' }),
        { headers: { ...headers, 'Content-Type': 'application/json' }, status: 400 }
      );
    }

    // Format phone number to E.164 format if needed
    let formattedPhoneNumber = phoneNumber;
    if (!phoneNumber.startsWith('+')) {
      formattedPhoneNumber = `+${phoneNumber}`;
    }

    // Generate verification code (6 digits)
    const verificationCode = Math.floor(100000 + Math.random() * 900000).toString();

    // Send SMS via Twilio
    const message = await twilioClient.messages.create({
      body: `رمز التحقق الخاص بك هو: ${verificationCode}`,
      to: formattedPhoneNumber,
      from: Deno.env.get('TWILIO_PHONE_NUMBER')
    });

    // Store verification code in database
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') || '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || ''
    );

    const { error: dbError } = await supabase
      .from('phone_verification_codes')
      .insert({
        user_id: req.headers.get('x-user-id'),
        phone: formattedPhoneNumber,
        code: verificationCode
      });

    if (dbError) throw dbError;

    return new Response(
      JSON.stringify({ success: true, messageId: message.sid }),
      { headers: { ...headers, 'Content-Type': 'application/json' }, status: 200 }
    );
  } catch (error) {
    console.error('Error sending verification code:', error);
    
    return new Response(
      JSON.stringify({ error: 'حدث خطأ أثناء إرسال رمز التحقق' }),
      { headers: { 'Content-Type': 'application/json' }, status: 500 }
    );
  }
});