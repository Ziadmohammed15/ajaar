CREATE TABLE properties (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID REFERENCES auth.users NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  price NUMERIC(10,2) NOT NULL,
  location TEXT,
  amenities JSONB,
  images TEXT[],
  is_available BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- سياسات الأمان للعقارات
ALTER TABLE properties ENABLE ROW LEVEL SECURITY;

CREATE POLICY "الجميع يمكنهم رؤية العقارات المتاحة"
ON properties FOR SELECT
TO authenticated
USING (is_available = TRUE);

CREATE POLICY "الملاك يمكنهم إدارة عقاراتهم"
ON properties FOR ALL
TO authenticated
USING (auth.uid() = owner_id);