/*
  # Admin Setup and User Roles
  
  1. Tables
    - admin_users: Admin specific data
    - user_roles: User role management
  
  2. Security
    - Admin-specific policies
    - Role-based access control
*/

-- Create admin_users table
CREATE TABLE IF NOT EXISTS admin_users (
  id uuid PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  super_admin boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Add role column to profiles
ALTER TABLE profiles 
ADD COLUMN IF NOT EXISTS role text 
CHECK (role IN ('admin', 'provider', 'client'));

-- Admin policies
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Only super admins can view admin users"
ON admin_users FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admin_users
    WHERE id = auth.uid() AND super_admin = true
  )
);

-- Update profiles policies for admin access
CREATE POLICY "Admins can view all profiles"
ON profiles FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admin_users WHERE id = auth.uid()
  )
);

CREATE POLICY "Admins can update all profiles"
ON profiles FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admin_users WHERE id = auth.uid()
  )
);

CREATE POLICY "Admins can delete profiles"
ON profiles FOR DELETE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admin_users WHERE id = auth.uid()
  )
);

-- Services policies for admin access
CREATE POLICY "Admins can manage all services"
ON services FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admin_users WHERE id = auth.uid()
  )
);

-- Function to create admin user
CREATE OR REPLACE FUNCTION create_admin_user(
  phone_number text,
  password text,
  name text,
  is_super_admin boolean DEFAULT false
) RETURNS uuid AS $$
DECLARE
  new_user_id uuid;
BEGIN
  -- Create auth user
  new_user_id := (
    SELECT id FROM auth.users 
    WHERE phone = phone_number
    LIMIT 1
  );
  
  IF new_user_id IS NULL THEN
    new_user_id := gen_random_uuid();
    
    INSERT INTO auth.users (
      id,
      phone,
      encrypted_password,
      raw_app_meta_data,
      raw_user_meta_data
    ) VALUES (
      new_user_id,
      phone_number,
      crypt(password, gen_salt('bf')),
      jsonb_build_object('provider', 'phone', 'providers', ARRAY['phone']),
      jsonb_build_object('phone_verified', true)
    );
  END IF;

  -- Create profile
  INSERT INTO profiles (id, phone, name, role, phone_verified)
  VALUES (new_user_id, phone_number, name, 'admin', true);

  -- Create admin user
  INSERT INTO admin_users (id, super_admin)
  VALUES (new_user_id, is_super_admin);

  RETURN new_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to create provider user
CREATE OR REPLACE FUNCTION create_provider_user(
  phone_number text,
  password text,
  name text
) RETURNS uuid AS $$
DECLARE
  new_user_id uuid;
BEGIN
  -- Create auth user
  new_user_id := gen_random_uuid();
  
  INSERT INTO auth.users (
    id,
    phone,
    encrypted_password,
    raw_app_meta_data,
    raw_user_meta_data
  ) VALUES (
    new_user_id,
    phone_number,
    crypt(password, gen_salt('bf')),
    jsonb_build_object('provider', 'phone', 'providers', ARRAY['phone']),
    jsonb_build_object('phone_verified', true)
  );

  -- Create profile
  INSERT INTO profiles (id, phone, name, role, phone_verified)
  VALUES (new_user_id, phone_number, name, 'provider', true);

  RETURN new_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to create client user
CREATE OR REPLACE FUNCTION create_client_user(
  phone_number text,
  password text,
  name text
) RETURNS uuid AS $$
DECLARE
  new_user_id uuid;
BEGIN
  -- Create auth user
  new_user_id := gen_random_uuid();
  
  INSERT INTO auth.users (
    id,
    phone,
    encrypted_password,
    raw_app_meta_data,
    raw_user_meta_data
  ) VALUES (
    new_user_id,
    phone_number,
    crypt(password, gen_salt('bf')),
    jsonb_build_object('provider', 'phone', 'providers', ARRAY['phone']),
    jsonb_build_object('phone_verified', true)
  );

  -- Create profile
  INSERT INTO profiles (id, phone, name, role, phone_verified)
  VALUES (new_user_id, phone_number, name, 'client', true);

  RETURN new_user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create initial admin user
SELECT create_admin_user(
  '+966500000001',  -- Admin phone
  'Admin123!',      -- Admin password
  'Super Admin',    -- Admin name
  true              -- Is super admin
);

-- Create sample provider
SELECT create_provider_user(
  '+966500000002',  -- Provider phone
  'Provider123!',   -- Provider password
  'Sample Provider' -- Provider name
);

-- Create sample client
SELECT create_client_user(
  '+966500000003',  -- Client phone
  'Client123!',     -- Client password
  'Sample Client'   -- Client name
);