CREATE TABLE rentals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id UUID REFERENCES properties NOT NULL,
  renter_id UUID REFERENCES profiles NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  total_price NUMERIC(10,2) NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- سياسات الأمان للتأجيرات
ALTER TABLE rentals ENABLE ROW LEVEL SECURITY;

CREATE POLICY "المستأجرون يمكنهم رؤية تأجيراتهم"
ON rentals FOR SELECT
TO authenticated
USING (auth.uid() = renter_id);

CREATE POLICY "الملاك يمكنهم رؤية تأجيرات عقاراتهم"
ON rentals FOR SELECT
TO authenticated
USING (
  EXISTS (SELECT 1 FROM properties WHERE id = rentals.property_id AND owner_id = auth.uid())
);